using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MiniGame : MonoBehaviour
{
    public float moveSpeed = 5f;
    public Animator animator;
    public string sceneToLoad;

    void Update()
    {
        Vector2 movement = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
        transform.Translate(movement * moveSpeed * Time.deltaTime);

        // ���������� ���������
        if (movement.y > 0)
        {
            animator.SetTrigger("W");
        }
        else if (movement.y < 0)
        {
            animator.SetTrigger("S");
        }
        else if (movement.x < 0)
        {
            animator.SetTrigger("A");
        }
        else if (movement.x > 0)
        {
            animator.SetTrigger("D");
        }

        // ���� �������� �� ��������
        if (movement == Vector2.zero)
        {
            animator.SetTrigger("idle");
        }
    }
}
