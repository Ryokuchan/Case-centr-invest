using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Student : MonoBehaviour
{
    int money;
    int broke;
    public string sceneToLoad;
    public string sceneToLoad1;
    public Button b;
    public Button a;

    
    public void Yes()
    {
        money++;
        SceneManager.LoadScene(sceneToLoad);
    }
    
    public void No()
    {
        broke++;
        SceneManager.LoadScene(sceneToLoad);
    }
    public void End()
    {
        if (money > broke)
        {
            SceneManager.LoadScene(sceneToLoad);
        }
        else
        {
            SceneManager.LoadScene(sceneToLoad1);
        }
    }
}
